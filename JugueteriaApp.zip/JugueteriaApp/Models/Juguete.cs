using System;
using System.ComponentModel.DataAnnotations;

namespace JugueteriaApp.Models
{
    public class Juguete
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "El código es requerido.")]
        public int Codigo { get; set; }

        [Required(ErrorMessage = "El nombre es requerido.")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres.")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El precio es requerido.")]
        [Range(0, double.MaxValue, ErrorMessage = "El precio debe ser mayor o igual a 0.")]
        public decimal Precio { get; set; }

        public DateTime? Vigencia { get; set; }

        public bool Activo { get; set; }

        // Propiedad de navegación para la relación con Marca
        public Guid MarcaId { get; set; }
        public Marca Marca { get; set; }
    }
}
