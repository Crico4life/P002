using Microsoft.EntityFrameworkCore;
using JugueteriaApp.Models; 

namespace JugueteriaApp.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Juguete> Juguetes { get; set; }
        public DbSet<Marca> Marcas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Juguete>()
                .Property(j => j.Precio)
                .HasColumnType("decimal(18, 2)");

            

            base.OnModelCreating(modelBuilder);
        }
    }
}
