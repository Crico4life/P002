using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JugueteriaApp.Models;

namespace JugueteriaApp.Controllers
{
    public class JuguetesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public JuguetesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Juguetes.ToListAsync());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Juguete juguete)
        {
            if (ModelState.IsValid)
            {
                juguete.Id = Guid.NewGuid();
                _context.Add(juguete);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(juguete);
        }

        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var juguete = await _context.Juguetes.FindAsync(id);
            if (juguete == null)
            {
                return NotFound();
            }
            return View(juguete);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, Juguete juguete)
        {
            if (id != juguete.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(juguete);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!JugueteExists(juguete.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(juguete);
        }

        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var juguete = await _context.Juguetes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (juguete == null)
            {
                return NotFound();
            }

            return View(juguete);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var juguete = await _context.Juguetes.FindAsync(id);
            _context.Juguetes.Remove(juguete);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool JugueteExists(Guid id)
        {
            return _context.Juguetes.Any(e => e.Id == id);
        }
    }
}
